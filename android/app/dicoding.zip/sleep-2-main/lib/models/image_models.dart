part of 'models.dart';

class ButtonImages {
  final int id;
  final String imageUrl;
  final String name;

  ButtonImages({
    required this.id,
    required this.imageUrl,
    required this.name,
  });
}
